Mohammed Younis Mohammed Salih
Lab 1 for Se 355
Instructed by Yad Tahir

for the lab to be completed You have to initialize each application i.e. class A,B,C, and D each independently,
and You have to start form class D all the way to class A.

What does this small system does?

class A will generate a random number, and It will send it to program B
B reads it, and It will send it to program C, and penultimately, C will Send it to D. D will finally send it to A and A will Print it in the terminal.

: )